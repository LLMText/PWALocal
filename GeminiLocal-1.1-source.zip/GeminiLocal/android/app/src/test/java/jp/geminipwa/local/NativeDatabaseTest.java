package jp.geminipwa.local;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.json.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=28)
public class NativeDatabaseTest {
 NativeDatabase db;
 @Before public void setUp(){RuntimeEnvironment.getApplication().deleteDatabase("conversations.sqlite");db=new NativeDatabase(RuntimeEnvironment.getApplication());}
 @After public void close(){db.close();}
 JSONObject q(String op,String store)throws Exception{return new JSONObject().put("op",op).put("store",store);}
 @Test public void largeUnicodeSurvivesCloseReopen()throws Exception{
  String payload="あ🦊".repeat(900000);
  Object id=db.execute(q("add","chats").put("payload",payload));
  db.close();db=new NativeDatabase(RuntimeEnvironment.getApplication());
  JSONObject row=(JSONObject)db.execute(q("get","chats").put("key",id));
  assertEquals(payload,row.getString("payload"));
 }
 @Test public void failedWriteRollsBackPreviousValue()throws Exception{
  Object id=db.execute(q("add","chats").put("payload","original"));
  try{db.execute(q("put","chats").put("key",id));fail("Expected missing payload failure");}catch(JSONException expected){}
  assertEquals("original",((JSONObject)db.execute(q("get","chats").put("key",id))).getString("payload"));
 }
 @Test public void deleteAndClearPreserveOtherStore()throws Exception{
  db.execute(q("put","settings").put("key","theme").put("payload","dark"));
  Object id=db.execute(q("add","chats").put("payload","chat"));
  try{db.execute(q("add","chats").put("key",id).put("payload","duplicate"));fail();}catch(IllegalArgumentException expected){}
  db.execute(q("delete","chats").put("key",id));
  assertEquals(JSONObject.NULL,db.execute(q("get","chats").put("key",id)));
  db.execute(q("add","chats").put("payload","chat2"));db.execute(q("clear","chats"));
  assertEquals(0,((JSONArray)db.execute(q("all","chats"))).length());
  assertEquals(1,((JSONArray)db.execute(q("all","settings"))).length());
  db.execute(new JSONObject().put("op","clearAll"));
  assertEquals(0,((JSONArray)db.execute(q("all","settings"))).length());
 }
}
