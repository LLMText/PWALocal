package jp.geminipwa.local;

import android.view.View;
import android.widget.FrameLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.WindowInsetsCompat;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=30)
public class SafeAreaLayoutTest {
    private WindowInsetsCompat insets(int top, int right, int bottom, int keyboard, int cutoutLeft) {
        return new WindowInsetsCompat.Builder()
            .setInsets(WindowInsetsCompat.Type.statusBars(), Insets.of(0,top,0,0))
            .setInsets(WindowInsetsCompat.Type.navigationBars(), Insets.of(0,0,right,bottom))
            .setInsets(WindowInsetsCompat.Type.displayCutout(), Insets.of(cutoutLeft,0,0,0))
            .setInsets(WindowInsetsCompat.Type.ime(), Insets.of(0,0,0,keyboard)).build();
    }
    private View child(SafeAreaLayout layout) {
        View child = new View(RuntimeEnvironment.getApplication());
        layout.addView(child,new FrameLayout.LayoutParams(-1,-1)); return child;
    }
    private void measure(SafeAreaLayout layout) {
        layout.measure(View.MeasureSpec.makeMeasureSpec(400, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(800, View.MeasureSpec.EXACTLY));
        layout.layout(0,0,400,800);
    }
    @Test @Config(sdk=28) public void barsReduceActualViewportIncludingFixedHtmlEdges() {
        SafeAreaLayout layout = new SafeAreaLayout(RuntimeEnvironment.getApplication()); View child=child(layout);
        layout.applySafeInsets(insets(28,0,48,0,0)); measure(layout);
        assertEquals(28,child.getTop()); assertEquals(752,child.getBottom());
        assertEquals(724,child.getMeasuredHeight());
        layout.applySafeInsets(insets(28,0,48,0,0)); measure(layout);
        assertEquals(724,child.getMeasuredHeight()); // repeat does not accumulate padding
    }
    @Test @Config(sdk=28) public void keyboardUsesMaximumAndClosingRestoresViewport() {
        SafeAreaLayout layout = new SafeAreaLayout(RuntimeEnvironment.getApplication()); View child=child(layout);
        layout.applySafeInsets(insets(28,0,24,300,0)); measure(layout);
        assertEquals(500,child.getBottom()); assertEquals(472,child.getMeasuredHeight());
        layout.applySafeInsets(insets(28,0,24,0,0)); measure(layout);
        assertEquals(776,child.getBottom());
    }
    @Test public void landscapeCutoutAndSideNavigationInsetBothSides() {
        SafeAreaLayout layout = new SafeAreaLayout(RuntimeEnvironment.getApplication()); View child=child(layout);
        layout.applySafeInsets(insets(0,48,0,0,32)); measure(layout);
        assertEquals(32,child.getLeft()); assertEquals(352,child.getRight());
        assertEquals(320,child.getMeasuredWidth());
    }
}
