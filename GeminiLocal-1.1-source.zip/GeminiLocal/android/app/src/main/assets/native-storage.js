/* Android-only persistence adapter. IndexedDB is never used as a fallback. */
(function (root) {
    'use strict';
    const bridge = root.NativeStorage;
    if (!bridge) return;
    let nextId = 1;
    const pending = new Map();
    function call(query) {
        return new Promise((resolve, reject) => {
            const requestId = nextId++;
            pending.set(requestId, { resolve, reject });
            try { bridge.postMessage(JSON.stringify({ ...query, requestId })); }
            catch (e) { pending.delete(requestId); reject(e); }
        });
    }
    bridge.onmessage = event => {
        const response = JSON.parse(event.data);
        const item = pending.get(response.requestId);
        if (!item) return;
        pending.delete(response.requestId);
        if (response.error) item.reject(new Error(response.error)); else item.resolve(response.result);
    };
    function showFailure(error) {
        if (!root.document) return;
        let banner = document.getElementById('native-storage-error');
        if (!banner) {
            banner = document.createElement('div'); banner.id = 'native-storage-error';
            banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#a31515;color:white;padding:12px;font-size:14px;';
            document.body.appendChild(banner);
        }
        banner.textContent = '端末への保存・読み込みに失敗しました。未保存の会話がある可能性があります。アプリを閉じずバックアップしてください。詳細: ' + error.message;
    }
    // Tagged recursive encoding preserves Blobs, undefined, dates and arrays without key collisions.
    async function encode(value) {
        if (value === undefined) return ['u'];
        if (value instanceof Blob) {
            const bytes = new Uint8Array(await value.arrayBuffer());
            let binary = ''; for (let i=0;i<bytes.length;i+=8192) binary += String.fromCharCode(...bytes.subarray(i,i+8192));
            return ['b', value.type, btoa(binary)];
        }
        if (value instanceof Date) return ['d',value.toISOString()];
        if (Array.isArray(value)) return ['a',await Promise.all(value.map(encode))];
        if (value !== null && typeof value === 'object') return ['o',await Promise.all(Object.entries(value).map(async ([k,v])=>[k,await encode(v)]))];
        return ['v',value];
    }
    function decode(value) {
        switch (value[0]) {
            case 'u': return undefined;
            case 'b': return new Blob([Uint8Array.from(atob(value[2]),c=>c.charCodeAt(0))], {type:value[1]});
            case 'd': return new Date(value[1]);
            case 'a': return value[1].map(decode);
            case 'o': return Object.fromEntries(value[1].map(([k,v])=>[k,decode(v)]));
            case 'v': return value[1];
            default: throw new Error('保存データの形式を認識できません。データは変更していません。');
        }
    }
    let queue = Promise.resolve();
    function serial(fn) { const task=queue.then(fn); queue=task.catch(()=>{}); return task; }
    function request(fn) {
        const req = {};
        // A task turn allows callers to attach handlers, including after await openDB().
        serial(fn).then(result => setTimeout(()=> { req.result=result; req.onsuccess?.({target:req}); },0),error=>setTimeout(()=> {
            req.error=error; showFailure(error); req.onerror?.({target:req});
        },0));
        return req;
    }
    function unpack(row, store) {
        if (row === null) return undefined;
        const value = decode(JSON.parse(row.payload));
        if (store === 'chats') value.id=Number(row.key);
        return value;
    }
    function store(name, mode='readonly') {
        if (!['chats','settings'].includes(name)) throw new Error('Unknown store');
        const write = (op, value) => {
            if (mode !== 'readwrite') throw new Error('Readonly store');
            const copy=structuredClone(value);
            return request(async ()=>call({op,store:name,key:name==='chats'?copy.id:copy.key,payload:JSON.stringify(await encode(copy))}));
        };
        const all = async ()=>(await call({op:'all',store:name})).map(row=>unpack(row,name));
        return {
            get: key=>request(async()=>unpack(await call({op:'get',store:name,key}),name)),
            getAll: ()=>request(all),
            put: value=>write('put',value), add: value=>write('add',value),
            delete: key=>{if(mode!=='readwrite')throw new Error('Readonly store');return request(()=>call({op:'delete',store:name,key}));},
            clear: ()=>{if(mode!=='readwrite')throw new Error('Readonly store');return request(()=>call({op:'clear',store:name}));},
            indexNames: { contains: ()=>true },
            index: field=>({openCursor: (_query,direction)=> {
                const req={};
                serial(all).then(rows=> {
                    const property = field === 'createdAtIndex' ? 'createdAt' : 'updatedAt';
                    rows.sort((a,b)=>(a[property]-b[property])||(a.id-b.id));
                    if(direction==='prev') rows.reverse();
                    let i=0;
                    function emit() { setTimeout(()=> {
                        req.result=i<rows.length ? {value:rows[i++],continue:emit} : null;
                        req.onsuccess?.({target:req});
                    },0); }
                    emit();
                },error=>setTimeout(()=>{req.error=error;showFailure(error);req.onerror?.({target:req});},0));
                return req;
            }})
        };
    }
    root.nativePersistence = {
        async open() { try { await call({op:'ping'}); return true; } catch(e) {showFailure(e); throw e;} },
        store,
        async clearAll() { try { await serial(()=>call({op:'clearAll'})); } catch(e) {showFailure(e);throw e;} },
        async exportBlob(blob,name) {
            const encoded=await encode(blob);
            return call({op:'export',name,mime:blob.type.split(';')[0]||'application/octet-stream',base64:encoded[2]});
        }
    };
})(globalThis);
