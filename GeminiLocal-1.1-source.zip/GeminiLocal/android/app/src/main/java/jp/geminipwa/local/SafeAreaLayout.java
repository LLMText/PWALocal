package jp.geminipwa.local;

import android.content.Context;
import android.graphics.Color;
import android.widget.FrameLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** Keeps the entire HTML viewport outside bars, cutouts, and the keyboard. */
final class SafeAreaLayout extends FrameLayout {
    SafeAreaLayout(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(24, 24, 24));
        ViewCompat.setOnApplyWindowInsetsListener(this, (view, windowInsets) -> {
            applySafeInsets(windowInsets);
            // Children already occupy the safe viewport; do not apply insets twice.
            return WindowInsetsCompat.CONSUMED;
        });
    }
    void applySafeInsets(WindowInsetsCompat windowInsets) {
        // getInsets unions these types using the maximum on each edge, so the
        // navigation bar is not added again when the keyboard covers it.
        Insets safe = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars()
                | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
        setPadding(safe.left, safe.top, safe.right, safe.bottom);
    }
}
