package jp.geminipwa.local;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.*;

/** Committed app-private SQLite storage. Chunking avoids CursorWindow limits for long chats. */
final class NativeDatabase extends SQLiteOpenHelper {
    NativeDatabase(Context context) { super(context, "conversations.sqlite", null, 1); }
    @Override public void onConfigure(SQLiteDatabase db) { db.execSQL("PRAGMA synchronous=FULL"); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE records (id INTEGER PRIMARY KEY AUTOINCREMENT, store TEXT NOT NULL, key TEXT, UNIQUE(store,key))");
        db.execSQL("CREATE TABLE chunks (record_id INTEGER NOT NULL, seq INTEGER NOT NULL, content TEXT NOT NULL, PRIMARY KEY(record_id,seq))");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { throw new IllegalStateException("Unsupported database upgrade; data preserved"); }
    private long find(SQLiteDatabase db, String store, String key) {
        try (Cursor c = db.rawQuery("SELECT id FROM records WHERE store=? AND key=?", new String[]{store,key})) { return c.moveToFirst() ? c.getLong(0) : -1; }
    }
    private JSONObject read(SQLiteDatabase db, long id, String key) throws Exception {
        StringBuilder text = new StringBuilder();
        try (Cursor c = db.rawQuery("SELECT content FROM chunks WHERE record_id=? ORDER BY seq", new String[]{""+id})) { while(c.moveToNext()) text.append(c.getString(0)); }
        return new JSONObject().put("key",key).put("payload",text.toString());
    }
    synchronized Object execute(JSONObject q) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        String op=q.getString("op");
        if (op.equals("ping")) return true;
        if (op.equals("clearAll")) {
            db.beginTransaction();
            try { db.delete("chunks",null,null); db.delete("records",null,null); db.setTransactionSuccessful(); }
            finally { db.endTransaction(); }
            return true;
        }
        String store=q.getString("store");
        if (!store.equals("chats") && !store.equals("settings")) throw new IllegalArgumentException("Unknown store");
        String key=q.has("key")&&!q.isNull("key") ? q.get("key").toString() : null;
        if(op.equals("get")) { long id=find(db,store,key); return id<0 ? JSONObject.NULL : read(db,id,key); }
        if(op.equals("all")) {
            JSONArray result=new JSONArray();
            try(Cursor c=db.rawQuery("SELECT id,key FROM records WHERE store=? ORDER BY id",new String[]{store})) { while(c.moveToNext()) result.put(read(db,c.getLong(0),c.getString(1))); }
            return result;
        }
        db.beginTransaction();
        Object result=true;
        try {
            if(op.equals("put") || op.equals("add")) {
                long id=key==null ? -1 : find(db,store,key);
                if(id>=0 && op.equals("add")) throw new IllegalArgumentException("Duplicate key");
                if(id<0) {
                    ContentValues row=new ContentValues(); row.put("store",store); row.put("key",key);
                    id=db.insertOrThrow("records",null,row);
                    if(key==null) { key=""+id; row.clear(); row.put("key",key); db.update("records",row,"id=?",new String[]{""+id}); }
                }
                String payload=q.getString("payload");
                db.delete("chunks","record_id=?",new String[]{""+id});
                // 32K UTF-16 units; avoid splitting surrogate pairs.
                for(int start=0,seq=0;start<payload.length();seq++) {
                    int end=Math.min(start+32768,payload.length());
                    if(end<payload.length() && Character.isHighSurrogate(payload.charAt(end-1))) end--;
                    ContentValues row=new ContentValues(); row.put("record_id",id); row.put("seq",seq); row.put("content",payload.substring(start,end));
                    db.insertOrThrow("chunks",null,row); start=end;
                }
                result=store.equals("chats") ? Long.valueOf(key) : key;
            } else if(op.equals("delete")) {
                long id=find(db,store,key); db.delete("chunks","record_id=?",new String[]{""+id}); db.delete("records","id=?",new String[]{""+id});
            } else if(op.equals("clear")) {
                db.execSQL("DELETE FROM chunks WHERE record_id IN (SELECT id FROM records WHERE store=?)",new Object[]{store});
                db.delete("records","store=?",new String[]{store});
            } else throw new IllegalArgumentException("Unknown operation");
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return result;
    }
}
