package jp.geminipwa.local;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.webkit.*;
import androidx.core.view.WindowCompat;
import androidx.core.view.ViewCompat;
import android.widget.FrameLayout;
import android.widget.Toast;
import androidx.webkit.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;
import java.io.*;

public final class MainActivity extends Activity {
    private WebView web;
    private NativeDatabase database;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private ValueCallback<Uri[]> upload;
    private byte[] exportBytes;
    private JavaScriptReplyProxy exportReply;
    private long exportId;
    private static final String ORIGIN="https://appassets.androidplatform.net";
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        database=new NativeDatabase(this);
        web=new WebView(this);
        // Shrink the WebView viewport itself; padding WebView does not reliably
        // inset HTML position:fixed headers and footers.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        SafeAreaLayout content = new SafeAreaLayout(this);
        content.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(content);
        ViewCompat.requestApplyInsets(content);
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false); settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        WebViewAssetLoader assets=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request) { return assets.shouldInterceptRequest(request.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {
                Uri url=request.getUrl();
                if(url.toString().startsWith(ORIGIN+"/assets/index.html") && request.isForMainFrame()) return false;
                if(request.isForMainFrame() && ("https".equals(url.getScheme()) || "http".equals(url.getScheme()))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,url)); } catch(Exception ignored) {}
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params) {
                if(upload!=null) upload.onReceiveValue(null);
                upload=callback;
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE);
                try { startActivityForResult(intent,10); } catch(Exception e) { upload.onReceiveValue(null); upload=null; }
                return true;
            }
            @Override public boolean onJsAlert(WebView v,String url,String message,JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("OK",(d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show(); return true;
            }
            @Override public boolean onJsConfirm(WebView v,String url,String message,JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("OK",(d,w)->result.confirm()).setNegativeButton("キャンセル",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show(); return true;
            }
        });
        if(!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            new AlertDialog.Builder(this).setMessage("Android System WebViewを更新してから再度起動してください。").setPositiveButton("終了",(d,w)->finish()).setCancelable(false).show(); return;
        }
        WebViewCompat.addWebMessageListener(web,"NativeStorage",Collections.singleton(ORIGIN),(view,message,source,isMain,reply)-> {
            if(!isMain || !"https".equals(source.getScheme()) || !"appassets.androidplatform.net".equals(source.getHost()) || (source.getPort()!=-1 && source.getPort()!=443)) return;
            try {
                JSONObject q=new JSONObject(message.getData()); long id=q.getLong("requestId");
                if(q.getString("op").equals("export")) {
                    if(exportReply!=null) { respond(reply,id,null,"別の保存操作が進行中です"); return; }
                    exportBytes=android.util.Base64.decode(q.getString("base64"),android.util.Base64.DEFAULT);
                    exportReply=reply; exportId=id;
                    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(q.optString("mime","application/octet-stream"));
                    intent.putExtra(Intent.EXTRA_TITLE,q.getString("name"));
                    try { startActivityForResult(intent,11); } catch(Exception e) { respond(reply,id,null,e.toString()); exportReply=null; exportBytes=null; }
                } else {
                    io.execute(()-> { try { respond(reply,id,database.execute(q),null); } catch(Exception e) { respond(reply,id,null,e.toString()); } });
                }
            } catch(Exception e) { Toast.makeText(this,"処理エラー: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        });
        web.loadUrl(ORIGIN+"/assets/index.html#chat");
    }
    private void respond(JavaScriptReplyProxy reply,long id,Object result,String error) {
        runOnUiThread(()-> { try {
            JSONObject response=new JSONObject().put("requestId",id);
            if(error==null) response.put("result",result==null?JSONObject.NULL:result); else response.put("error",error);
            reply.postMessage(response.toString());
        } catch(Exception ignored) {} });
    }
    @Override protected void onActivityResult(int code,int result,Intent data) {
        super.onActivityResult(code,result,data);
        if(code==10 && upload!=null) {
            upload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data)); upload=null;
        }
        if(code==11 && exportReply!=null) {
            JavaScriptReplyProxy reply=exportReply; long id=exportId; byte[] bytes=exportBytes; exportReply=null; exportBytes=null;
            if(result!=RESULT_OK || data==null || data.getData()==null) { respond(reply,id,null,"保存をキャンセルしました"); return; }
            Uri uri=data.getData();
            io.execute(()-> {
                try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")) {
                    if(out==null) throw new IOException("保存先を開けませんでした"); out.write(bytes); out.flush();
                } catch(Exception e) { respond(reply,id,null,e.toString()); return; }
                respond(reply,id,true,null);
            });
        }
    }
    @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(upload!=null) upload.onReceiveValue(null); web.destroy(); io.execute(()->database.close()); io.shutdown(); super.onDestroy(); }
}
