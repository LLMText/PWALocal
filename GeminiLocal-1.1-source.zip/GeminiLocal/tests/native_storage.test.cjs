const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
function app(records=new Map()) {
 let lastId=0, fail=false;
 const native={postMessage(raw) {
  const q=JSON.parse(raw); let result, error;
  try {
   if(fail) throw Error('disk full');
   const key=q.store+':'+q.key;
   if(q.op==='ping') result=true;
   else if(q.op==='clearAll') { records.clear();result=true; }
   else if(q.op==='put'||q.op==='add') {
    const id=q.key??++lastId, k=q.store+':'+id;
    if(q.op==='add'&&records.has(k))throw Error('Duplicate key');
    records.set(k,{key:String(id),payload:q.payload});result=id;
   } else if(q.op==='get')result=records.get(key)??null;
   else if(q.op==='all')result=[...records].filter(([k])=>k.startsWith(q.store+':')).map(([,v])=>v);
   else if(q.op==='delete'){records.delete(key);result=true;}
   else if(q.op==='clear'){for(const k of records.keys())if(k.startsWith(q.store+':'))records.delete(k);result=true;}
  }catch(e){error=e.message;}
  setTimeout(()=>native.onmessage({data:JSON.stringify({requestId:q.requestId,result,error})}),0);
 }};
 const ctx=vm.createContext({NativeStorage:native,Blob,Uint8Array,btoa,atob,structuredClone,setTimeout,Date});
 vm.runInContext(fs.readFileSync('native-storage.js','utf8'),ctx);
 return {api:ctx.nativePersistence,records,fail:()=>fail=true};
}
const req=r=>new Promise((resolve,reject)=>{r.onsuccess=e=>resolve(e.target.result);r.onerror=e=>reject(e.target.error);});
test('chat roundtrip after new app context, long Unicode text and Blob',async()=>{
 const a=app();await a.api.open();
 const content='長い会話🦊'.repeat(100000);
 const id=await req(a.api.store('chats','readwrite').add({messages:[{content,attachments:[{blob:new Blob(['画像データ'],{type:'text/plain'})}]}]}));
 const b=app(a.records);
 const chat=await req(b.api.store('chats').get(id));
 assert.equal(chat.id,id);assert.equal(chat.messages[0].content,content);
 assert.equal(await chat.messages[0].attachments[0].blob.text(),'画像データ');
});
test('settings do not lose false, null, arrays, undefined or unusual keys',async()=>{
 const {api}=app();const value={enabled:false,empty:null,items:[1,'two',undefined],__tag:'b'};
 await req(api.store('settings','readwrite').put({key:'test',value}));
 const rows=await req(api.store('settings').getAll());assert.equal(JSON.stringify(rows[0].value),JSON.stringify(value));
});
test('cursor order matches index, delete and clear isolate settings',async()=>{
 const {api}=app();const store=api.store('chats','readwrite');
 await req(store.add({updatedAt:1,createdAt:3}));await req(store.add({updatedAt:5,createdAt:1}));
 const order=await new Promise((resolve,reject)=>{
  const r=store.index('updatedAtIndex').openCursor(null,'prev'),out=[];
  r.onsuccess=e=>{const c=e.target.result;if(c){out.push(c.value.updatedAt);c.continue();}else resolve(out);};r.onerror=reject;
 });assert.deepEqual(order,[5,1]);
 await req(api.store('settings','readwrite').put({key:'keep',value:42}));
 await req(store.delete(1));assert.equal(await req(store.get(1)),undefined);
 await req(store.clear());assert.equal((await req(store.getAll())).length,0);
 assert.equal((await req(api.store('settings').get('keep'))).value,42);
 await api.clearAll();assert.equal((await req(api.store('settings').getAll())).length,0);
});
test('storage errors propagate and readonly writes are rejected',async()=>{
 const a=app();a.fail();await assert.rejects(req(a.api.store('chats','readwrite').put({messages:[]})),/disk full/);
 assert.throws(()=>a.api.store('chats').put({}),/Readonly/);
});
test('write snapshots caller data before async encoding',async()=>{
 const {api}=app();const value={key:'snap',value:{text:'before'}};
 const r=api.store('settings','readwrite').put(value);value.value.text='after';await req(r);
 assert.equal((await req(api.store('settings').get('snap'))).value.text,'before');
});
