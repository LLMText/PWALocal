# Gemini Local 1.1 — Android版

元リポジトリ: https://github.com/titan823/geminipwa
基準コミット: c04e3cb195f831bb99e9bec336a5d9afb5e769dc

## 1.0からの更新

`GeminiLocal-1.1.apk` を開き「更新」で上書きインストールしてください。
アプリIDと署名鍵は1.0と同一です。履歴・設定のDB形式は変更していません。
アンインストールは不要です（アンインストールすると端末内の履歴が消えます）。

1.1ではステータスバー・ナビゲーションバー・画面の切り欠き・キーボードを避ける領域に、WebView全体を配置します。
WebView自体に余白を設定する1.0の方式をやめ、外側のレイアウトを使ってHTMLの表示領域を縮めます。
画面上部・下部の固定ボタンも、その領域内に収まります。

## 使い始める

1. 旧PWAで「全セッション」のJSONバックアップを保存します。旧PWAのデータは消さないでください。
2. 同梱APKをAndroid端末にインストールします。
3. Gemini Localを開き、APIキーを設定します。
4. 履歴画面の全セッションインポートから旧JSONを選びます。
5. 短い会話を行い、アプリを終了して再起動し、履歴画面から同じ会話を開けることを確認します。

通常のChromeとは別アプリです。画面と基本機能は元PWAを利用し、履歴と設定の読み書きをアプリ専用SQLiteに置き換えています。
ブラウザの閲覧データ削除とは独立しています。アンインストール、Android設定でのアプリデータ削除、アプリ内の履歴削除ではデータが削除されます。

## 保存の範囲

送信・回答完了・編集など、元PWAの保存呼び出し時にSQLiteトランザクションを確定してから成功を返します。
強制終了前に保存が完了した会話は保持します。生成途中の未確定の回答、未送信の下書きの完全復元、バックグラウンド生成の継続は保証しません。
履歴と設定を端末内に保存します。クラウドへの履歴同期は追加していません。AIへの通信先・中継設定は元PWAの設定を引き継ぎます。
SQLiteの保存失敗・読み込み失敗は画面上部に表示します。
大きい会話はDB内で分割して保存し、AndroidのCursorWindowの1行サイズ制限を回避します。

既存のJSONバックアップ形式を維持しています。元形式が含めない設定・APIキー・画像等は、そのJSONからは復元できません。
バックアップ書き出しはAndroid標準の保存先選択画面を使用します。保存完了後に成功を通知します。
アプリ内DBはブラウザのキャッシュとは別の内部領域です。Android自動クラウドバックアップは無効です。

## 開発・ビルド

Java 17、Android SDK 35（Build Tools 35.0.0）、Gradle 8.11.1を用意してください。

```
python3 scripts/prepare_android.py
node --test tests/*.test.cjs
gradle -p android assembleDebug testDebugUnitTest
```

SDK位置は `ANDROID_HOME` または `android/local.properties` の `sdk.dir` に設定します。
APK: `android/app/build/outputs/apk/debug/app-debug.apk`
GitHub ActionsのAndroid APKワークフローは手動実行です。リポジトリへのアップロード・外部公開は行っていません。

`index.html` は元のまま保持し、`scripts/prepare_android.py` がAndroid用の差し替えを検査付きで適用します。
AndroidはWebView + AndroidX WebKitの専用シェルで、Capacitorは使用していません。
`native-storage.js` は元コードが使用するストア操作にのみ対応したアダプターです。汎用IndexedDB互換実装ではありません。
DBを使えない場合、IndexedDBへ自動的に戻ることはしません。
ネイティブとのメッセージはアプリ自身のオリジン・メインフレームのみに制限し、外部リンクは外部ブラウザで開きます。

## 検証と制限

検証結果は同梱のVALIDATION.txtを参照してください。
実機でのAPI応答、画面回転、ファイル提供アプリごとの選択動作、端末固有の省電力動作は別途確認が必要です。
元PWAのAPI仕様・表示機能をすべて実機検証したものではありません。
署名が異なるAPKを上書きインストールすることはできません。更新時は同じアプリIDと署名鍵を使ってください。

## ライセンス

元プロジェクトのMITライセンスをLICENSEに同梱しています。
追加したAndroidコード・アダプター・テストも同じMITライセンスです。
marked.jsは元リポジトリの同梱版、DOMPurify 3.0.5 / Mermaid 10.6.1は元PWAと同じバージョンを同梱しています。

## 同梱APKの更新用署名

配布する `GeminiLocal-1.1.apk` は個人用の鍵で署名したリリースビルドです（デバッグ不可）。
ソースZIPの `android/signing/` は同じ署名で更新するための鍵とパスワードです。公開リポジトリに載せず、このZIPを手元に保管してください。
同じ鍵を配置した状態で `gradle -p android assembleRelease` を実行すると更新用APKを作れます。
GitHub Actionsのdebug成果物は別署名なので、このリリース版への上書き更新には使えません。

UI統合テストはPlaywrightとChromiumを導入してから `node scripts/check_android_ui.cjs` で実行します。
任意のChromiumを使う場合は `CHROME_EXECUTABLE` に実行ファイルを指定します。
このテストはネイティブ通信をモックし、IndexedDBアクセスを禁止した状態で実画面の保存処理とバックアップ互換性を検証します。
