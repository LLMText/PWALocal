from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
out=root/'android/app/src/main/assets'
out.mkdir(parents=True,exist_ok=True)
text=(root/'index.html').read_text()
def replace_once(old,new):
    global text
    assert text.count(old)==1, (old[:100],text.count(old))
    text=text.replace(old,new)
replace_once('<script src="marked.js"></script>','<script src="native-storage.js"></script>\n    <script src="marked.js"></script>')
text=text.replace('https://cdn.jsdelivr.net/npm/dompurify@3.0.5/dist/purify.min.js','vendor/purify.min.js')
text=text.replace('https://cdn.jsdelivr.net/npm/mermaid@10.6.1/dist/mermaid.min.js','vendor/mermaid.min.js')
text=text.replace("securityLevel: 'loose'", "securityLevel: 'strict'")
replace_once('async openDB() {','async openDB() {\n                if (window.nativePersistence) return window.nativePersistence.open();')
replace_once("_getStore(storeName, mode = 'readonly') {", "_getStore(storeName, mode = 'readonly') {\n                if (window.nativePersistence) return window.nativePersistence.store(storeName, mode);")
replace_once('async clearAllData() {','async clearAllData() {\n                if (window.nativePersistence) return window.nativePersistence.clearAll();')
replace_once('async function clearAllSiteDataAndReload() {','async function clearAllSiteDataAndReload() {\n                if (window.nativePersistence) {\n                    if (!confirm("端末内の履歴と設定を全て削除しますか？")) return;\n                    try { await window.nativePersistence.clearAll(); window.location.reload(); }\n                    catch (e) { alert("削除に失敗しました: " + e.message); }\n                    return;\n                }')
# No network service worker can replace the bundled app.
text=text.replace("if ('serviceWorker' in navigator)","if (!window.nativePersistence && 'serviceWorker' in navigator)")
# Explicit export branches await Android's save completion (or cancellation).
needle="const blob = new Blob([exportText.trim()], { type: 'text/plain;charset=utf-8' });"
replace_once(needle,needle+'''\n                    if (window.nativePersistence) {
                        const name = (chatTitle || `chat_${chatId}`).replace(/[<>:"/\\\\|?*\\s]/g, '_');
                        await window.nativePersistence.exportBlob(blob, name + '.txt');
                        return;
                    }''')
needle="const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });"
replace_once(needle,needle+'''\n                    if (window.nativePersistence) {
                        await window.nativePersistence.exportBlob(blob, 'gemini_sessions_' + new Date().toISOString().slice(0,10) + '.json');
                        await uiUtils.showCustomAlert(`${chats.length}件のセッションを保存しました。`);
                        return;
                    }''')
# System picker providers sometimes omit JSON MIME type.
text=text.replace("if (!file || file.type !== 'application/json')", "if (!file || (file.type !== 'application/json' && !file.name.toLowerCase().endsWith('.json')))")
# Native database startup must fail visibly rather than silently opening a browser database.
text=text.replace('<title>', '<title>Android版 · ',1)
# Block frames/objects; scripts are bundled, while API endpoints remain configurable HTTPS.
text=text.replace('<head>', '''<head>
<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; connect-src 'self' https:; font-src 'self' data: https:; media-src 'self' blob: data: https:; worker-src 'self' blob:; frame-src 'none'; object-src 'none'; base-uri 'self';">''',1)
(out/'index.html').write_text(text)
for name in ['marked.js','native-storage.js','icon-192x192.png','manifest.json','LICENSE']:
    shutil.copy2(root/name,out/name)
shutil.copytree(root/'vendor',out/'vendor',dirs_exist_ok=True)
print('Android web assets prepared')
