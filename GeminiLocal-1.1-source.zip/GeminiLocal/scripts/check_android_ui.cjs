const {chromium}=require('playwright');const fs=require('fs');const path=require('path');const assert=require('assert/strict');
(async()=>{
const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_EXECUTABLE,args:['--no-sandbox']});const context=await browser.newContext();
const records=new Map();let id=0;let exported=null;
await context.exposeBinding('storageCall',(_,raw)=>{
 const q=JSON.parse(raw);let result;const key=q.store+':'+q.key;
 if(q.op==='export'){exported=q;result=true;}
 else if(q.op==='ping')result=true;
 else if(q.op==='put'||q.op==='add'){const k=q.key??++id;records.set(q.store+':'+k,{key:String(k),payload:q.payload});result=k;}
 else if(q.op==='get')result=records.get(key)??null;
 else if(q.op==='all')result=[...records].filter(([k])=>k.startsWith(q.store+':')).map(([,v])=>v);
 else if(q.op==='delete'){records.delete(key);result=true;}
 else if(q.op==='clear'){for(const k of records.keys())if(k.startsWith(q.store+':'))records.delete(k);result=true;}
 else if(q.op==='clearAll'){records.clear();result=true;}
 else throw Error('Unexpected operation '+q.op);
 return JSON.stringify({requestId:q.requestId,result});
});
await context.addInitScript(()=>{window.NativeStorage={postMessage(raw){window.storageCall(raw).then(data=>window.NativeStorage.onmessage({data}));}};Object.defineProperty(window,'indexedDB',{get(){throw Error('Native app used IndexedDB');}});});
await context.route('https://appassets.androidplatform.net/**',async route=>{
const p=path.join(path.resolve(__dirname,'../android/app/src/main/assets'),new URL(route.request().url()).pathname.replace('/assets/',''));
if(!fs.existsSync(p)){await route.fulfill({status:404,body:''});return;}
const type=p.endsWith('.html')?'text/html':p.endsWith('.js')?'application/javascript':p.endsWith('.json')?'application/json':'image/png';
await route.fulfill({body:fs.readFileSync(p),contentType:type});
});
const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('https://appassets.androidplatform.net/assets/index.html#chat');
await page.waitForFunction(()=>typeof dbUtils!=='undefined'&&typeof uiUtils!=='undefined');
await page.evaluate(async()=>{await dbUtils.openDB();await dbUtils.loadSettings();});
const saved=await page.evaluate(async()=>{
state.currentMessages=[{role:'user',content:'保存テスト🦊',timestamp:123}];state.currentChatId=null;
const id=await dbUtils.saveChat('端末保存テスト');await dbUtils.saveSetting('theme','dark');return id;
});
await page.reload();
const result=await page.evaluate(async id=>{await dbUtils.openDB();await dbUtils.loadSettings();const chat=await dbUtils.getChat(id);return {title:chat.title,text:chat.messages[0].content,theme:state.settings.theme,count:(await dbUtils.getAllChats()).length};},saved);
assert.equal(result.text,'保存テスト🦊');assert.equal(result.theme,'dark');assert.equal(result.count,1);
await page.evaluate(async()=>{uiUtils.showCustomConfirm=async()=>true;uiUtils.showCustomAlert=async()=>{};await appLogic.exportAllSessions();});
assert.equal(exported.mime,'application/json');
const backup=Buffer.from(exported.base64,'base64').toString('utf8');
assert.equal(JSON.parse(backup)[0].messages[0].content,'保存テスト🦊');
await page.evaluate(async text=>{await appLogic.handleAllSessionsImport(new File([text],'backup.json',{type:''}));},backup);
await page.waitForFunction(async()=>(await dbUtils.getAllChats()).length===2);
const imported=await page.evaluate(async saved=>(await dbUtils.getAllChats()).find(c=>c.id!==saved).id,saved);
await page.evaluate(async id=>{await dbUtils.deleteChat(id);},imported);
await page.evaluate(async id=>{await dbUtils.updateChatTitleDb(id,'改名');},saved);
assert.equal(await page.evaluate(async id=>(await dbUtils.getChat(id)).title,saved),'改名');
await page.evaluate(async id=>{await dbUtils.deleteChat(id);},saved);
assert.equal(await page.evaluate(async()=>(await dbUtils.getAllChats()).length),0);

await browser.close();assert.deepEqual(errors,[]);console.log('PASS: full UI initialization, no IndexedDB, save, reload, settings, JSON export/import, rename, delete');
})().catch(e=>{console.error(e);process.exit(1)});
